AMS-APP Render Escalation Packet
Generated at: 2026-04-06T09:16:43.540983+00:00
Severity: critical
Owner: Traction
Destination: Render support

What this packet is:
A send-ready evidence bundle for the current Render webhook routing outage blocking live Stripe trial signup validation.

Primary requested action:
Confirm the webhook hostname is attached to commission-tracker-webhook, redeploy the service, and recheck /health until x-render-routing=no-server disappears.

Recommended packet files:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- render.yaml
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Broader recommended attachments:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- docs/TRIAL_SIGNUP_E2E_REPORT_2026-04-01.md
- render.yaml
- docs/smoke-checks/owner-ready/traction.txt
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Live verification shell still needs these secrets before the final Stripe test:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRICE_ID
- RESEND_API_KEY
- SUPABASE_SERVICE_KEY

Integrity hashes:
- README.txt: sha256=bdca3f7078250086ba7fbf0c6db3c476e60c6315b3f26ac70dd11eaa51f898da size_bytes=3140
- evidence-manifest.json: sha256=b804fcedc210888286f4ad05bb1cf1703ac1a334b5cd50ac50ec80f76868310b size_bytes=10069
- latest-trial-signup-smoke-check.json: path=docs/smoke-checks/latest-trial-signup-smoke-check.json sha256=c4ff0dca381af0efb13b1668de522a63bf6819ac2734073da3dea364afbe796c size_bytes=48011
- latest-trial-signup-smoke-check.md: path=docs/smoke-checks/latest-trial-signup-smoke-check.md sha256=922c222ef15bf8c75ed3e222347481e7531ac9f782ad521099647e2a8da27d50 size_bytes=31405
- render-support-message.txt: sha256=a8a3f9230f6727af3322ab33439538ba697d8d37b56d6bd972e8b581abaab26b size_bytes=2406
- render-support-payload.json: sha256=b136d5817229672a06e91bb91ae4fac94ee90f7aef723c05d7924b84f3341bc6 size_bytes=1392

If forwarding to Render support:
1. Use escalation-packet.zip if the support channel accepts a single attachment, or send the individual files below.
2. Send render-support-message.txt as the support message body.
3. Attach render-support-payload.json and evidence-manifest.json.
4. Include the latest smoke-check JSON/Markdown artifacts and render.yaml from the packet file list above.
5. If packet integrity is questioned later, compare the attached files against the sha256 hashes listed above.
