AMS-APP Render Escalation Packet
Generated at: 2026-04-06T01:14:54.130152+00:00
Severity: critical
Owner: Traction
Destination: Render support

What this packet is:
A send-ready evidence bundle for the current Render webhook routing outage blocking live Stripe trial signup validation.

Primary requested action:
Confirm the webhook hostname is attached to commission-tracker-webhook, redeploy the service, and recheck /health until x-render-routing=no-server disappears.

Recommended packet files:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- render.yaml
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Broader recommended attachments:
- docs/smoke-checks/latest-trial-signup-smoke-check.json
- docs/smoke-checks/latest-trial-signup-smoke-check.md
- docs/TRIAL_SIGNUP_E2E_REPORT_2026-04-01.md
- render.yaml
- docs/smoke-checks/owner-ready/traction.txt
- docs/smoke-checks/owner-ready/render_support.txt
- docs/smoke-checks/escalation-packet/render-support-message.txt
- docs/smoke-checks/escalation-packet/render-support-payload.json
- docs/smoke-checks/escalation-packet/evidence-manifest.json
- docs/smoke-checks/escalation-packet/README.txt
- docs/smoke-checks/escalation-packet/escalation-packet.zip
- docs/smoke-checks/escalation-packet/escalation-packet.zip.sha256

Live verification shell still needs these secrets before the final Stripe test:
- STRIPE_SECRET_KEY
- STRIPE_WEBHOOK_SECRET
- STRIPE_PRICE_ID
- RESEND_API_KEY
- SUPABASE_SERVICE_KEY

Integrity hashes:
- README.txt: sha256=9b59897d83ffddfd592d27c9eb78738b4e4d90c3fed977ef787e032504364f3e size_bytes=3140
- evidence-manifest.json: sha256=8657670163ed771c319d511c5d9a1b62fa9bfdd2e7f56f0b00c44659f07d188c size_bytes=10069
- latest-trial-signup-smoke-check.json: path=docs/smoke-checks/latest-trial-signup-smoke-check.json sha256=e39fdb1eb3b65d3576a81da86b58065851e3ea7115e5355d2c9be5e63fde84c9 size_bytes=47553
- latest-trial-signup-smoke-check.md: path=docs/smoke-checks/latest-trial-signup-smoke-check.md sha256=1b598ae4dae0d909d03f8075a1f9b2ca256394b075a9d17a47e21a232ad611a0 size_bytes=31197
- render-support-message.txt: sha256=7ab3274ae6614c4ba82dcb4c0efeca1c1ffee0ccd2c742d0e9694d7ea2d6a0de size_bytes=2406
- render-support-payload.json: sha256=374eaf504446125dbfa52c79b93a1a9117b860f70d4bd64d1558a1c51cf1698a size_bytes=1392

If forwarding to Render support:
1. Use escalation-packet.zip if the support channel accepts a single attachment, or send the individual files below.
2. Send render-support-message.txt as the support message body.
3. Attach render-support-payload.json and evidence-manifest.json.
4. Include the latest smoke-check JSON/Markdown artifacts and render.yaml from the packet file list above.
5. If packet integrity is questioned later, compare the attached files against the sha256 hashes listed above.
